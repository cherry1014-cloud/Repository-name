#!/usr/bin/env python3
"""Lanumaren online rooms: one HTTP + WebSocket server, no DB or accounts required.

Run: python server.py  (after pip install -r requirements.txt)
Deploy to an HTTPS Python web service; client automatically uses wss://.../ws.
"""
import asyncio
import json
import math
import os
import re
import secrets
import socket
import time
import unicodedata
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from aiohttp import WSMsgType, web

HERE = Path(__file__).resolve().parent
HTML = HERE / "index.html"
PUBLIC_MAX = 12
PRIVATE_MAX = 8
rooms: dict[str, "Room"] = {}
active_connections: set[web.WebSocketResponse] = set()


def clean(value: Any, maxlen: int) -> str:
    if not isinstance(value, str):
        return ""
    value = unicodedata.normalize("NFKC", value)
    return "".join(c for c in value.strip() if c >= " " and c != "\x7f")[:maxlen]


def finite(value: Any, default: float = 0.0, bound: float = 1000000) -> float:
    try:
        val = float(value)
        if not math.isfinite(val):
            return default
        return max(-bound, min(bound, val))
    except (TypeError, ValueError, OverflowError):
        return default


def normalize_state(obj: Any) -> dict:
    if not isinstance(obj, dict):
        return {}
    p = {k: finite(obj.get(k)) for k in ("x", "z", "y", "yaw")}
    p["vessel"] = clean(obj.get("vessel"), 24) or "sloop"
    a = obj.get("actor")
    if isinstance(a, dict):
        p["actor"] = {
            **{k: finite(a.get(k)) for k in ("x", "y", "z", "yaw")},
            "move": max(0.0, min(1.0, finite(a.get("move")))),
            "sub": bool(a.get("sub")),
            "swim": bool(a.get("swim")),
        }
    return p


@dataclass
class Player:
    id: str
    nickname: str
    ws: web.WebSocketResponse
    room: "Room | None" = None
    state: dict = field(default_factory=dict)
    slot: int = 0
    last_state: float = 0.0

    def public(self) -> dict:
        return {"id": self.id, "nickname": self.nickname, "position": self.state}


@dataclass
class Room:
    code: str
    name: str
    visibility: str
    max: int
    players: dict[str, Player] = field(default_factory=dict)

    def info(self) -> dict:
        return {"code": self.code, "name": self.name,
                "visibility": self.visibility, "count": len(self.players), "max": self.max}


def new_code() -> str:
    while True:
        code = secrets.token_hex(8).upper()
        if code not in rooms:
            return code


async def send(ws: web.WebSocketResponse, data: dict) -> None:
    if not ws.closed:
        try:
            await ws.send_str(json.dumps(data, ensure_ascii=False, separators=(",", ":")))
        except (ConnectionResetError, RuntimeError):
            pass


async def publish(room: Room, data: dict, except_id: str = "") -> None:
    await asyncio.gather(*(send(p.ws, data) for p in list(room.players.values())
                           if p.id != except_id), return_exceptions=True)


async def leave(player: Player) -> None:
    room = player.room
    if room is None:
        return
    player.room = None
    room.players.pop(player.id, None)
    if not room.players:
        rooms.pop(room.code, None)
    else:
        await publish(room, {"type": "player_left", "id": player.id})
        await publish(room, {"type": "room_info", "room": room.info()})


def find_public(name: str) -> Room | None:
    key = unicodedata.normalize("NFKC", name).casefold()
    return next((r for r in rooms.values()
                 if r.visibility == "public" and r.name.casefold() == key), None)


def create_room(name: str, visibility: str) -> Room:
    room = Room(new_code(), name, visibility,
                PUBLIC_MAX if visibility == "public" else PRIVATE_MAX)
    rooms[room.code] = room
    return room


async def enter(player: Player, message: dict) -> None:
    if player.room:
        await send(player.ws, {"type": "error", "message": "이미 방에 입장해 있어요"})
        return
    nickname = clean(message.get("nickname"), 20)
    if not nickname:
        await send(player.ws, {"type": "error", "message": "닉네임을 입력해주세요"})
        return
    player.nickname = nickname
    action = message.get("action")
    room: Room | None = None
    if action == "create":
        name = clean(message.get("roomName"), 28)
        if len(name) < 2:
            await send(player.ws, {"type": "error", "message": "방 이름은 2글자 이상 입력하세요"})
            return
        visibility = "public" if message.get("visibility") == "public" else "private"
        if visibility == "public" and find_public(name):
            await send(player.ws, {"type": "error", "message": "같은 이름의 공개 방이 있습니다"})
            return
        room = create_room(name, visibility)
    elif action == "join":
        raw = clean(message.get("key"), 35)
        code = re.sub(r"[\s\-]", "", raw).upper()
        if re.fullmatch(r"[A-F0-9]{16}", code):
            room = rooms.get(code)
        else:
            room = find_public(raw)
        if room is None:
            await send(player.ws, {"type": "error", "message": "방을 찾을 수 없습니다. 초대 코드나 공개 방 이름을 확인해주세요"})
            return
    elif action == "random":
        public = [r for r in rooms.values() if r.visibility == "public" and len(r.players) < r.max]
        room = min(public, key=lambda r: len(r.players), default=None)
        if room is None:
            i = 1
            while find_public(f"공개 바다 {i}"):
                i += 1
            room = create_room(f"공개 바다 {i}", "public")
    else:
        await send(player.ws, {"type": "error", "message": "지원하지 않는 방 입장 방식입니다"})
        return

    if len(room.players) >= room.max:
        await send(player.ws, {"type": "error", "message": "이 방은 정원이 찼습니다"})
        return
    used = {p.slot for p in room.players.values()}
    slot = 0
    while slot in used:
        slot += 1
    spawn = {"x": (slot % 3) * 14, "z": -(slot // 3) * 14,
             "y": 0, "yaw": 1.29}
    existing = [p.public() for p in room.players.values()]
    player.slot = slot
    player.state = dict(spawn, vessel="sloop")
    player.room = room
    room.players[player.id] = player
    await send(player.ws, {
        "type": "joined", "you": player.id, "room": room.info(),
        "players": existing, "spawn": spawn
    })
    await publish(room, {"type": "player_joined", "player": player.public()}, player.id)
    await publish(room, {"type": "room_info", "room": room.info()}, player.id)
    print(f"[JOIN] {player.nickname} ({player.id}) {room.code} {len(room.players)}/{room.max}", flush=True)


async def handle_websocket(request: web.Request) -> web.WebSocketResponse:
    ws = web.WebSocketResponse(heartbeat=25.0, max_msg_size=8192)
    await ws.prepare(request)
    active_connections.add(ws)
    player = Player(uuid.uuid4().hex[:14], "항해자", ws)
    try:
        async for event in ws:
            if event.type == WSMsgType.TEXT:
                try:
                    message = json.loads(event.data)
                except (json.JSONDecodeError, TypeError):
                    continue
                if not isinstance(message, dict):
                    continue
                typ = message.get("type")
                if typ == "enter":
                    await enter(player, message)
                elif typ == "state" and player.room:
                    now = time.monotonic()
                    if now - player.last_state < 0.055:
                        continue
                    player.last_state = now
                    state = normalize_state(message.get("p"))
                    if not state:
                        continue
                    player.state = state
                    await publish(player.room, {"type": "player_state", "id": player.id, "p": state}, player.id)
            elif event.type in (WSMsgType.ERROR, WSMsgType.CLOSE):
                break
    except (ConnectionError, asyncio.CancelledError):
        pass
    finally:
        await leave(player)
        active_connections.discard(ws)
    return ws


async def handle_index(request: web.Request) -> web.FileResponse:
    response = web.FileResponse(HTML)
    response.headers["Cache-Control"] = "no-cache"
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


async def health(request: web.Request) -> web.Response:
    return web.json_response({"ok": True, "game": "lanumaren", "activeRooms": len(rooms),
                              "activePlayers": sum(len(r.players) for r in rooms.values())})


def lan_ips() -> list[str]:
    found = set()
    # Use a UDP socket only to discover the network adapter's source address.
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("192.0.2.1", 80))
            found.add(s.getsockname()[0])
    except OSError:
        pass
    try:
        found.update(socket.gethostbyname_ex(socket.gethostname())[2])
    except OSError:
        pass
    return sorted(ip for ip in found if ip and not ip.startswith("127."))


async def local_invite(request: web.Request) -> web.Response:
    port = int(os.getenv("PORT", "3000"))
    return web.json_response({"origins": [f"http://{ip}:{port}" for ip in lan_ips()]})


async def on_shutdown(app: web.Application) -> None:
    await asyncio.gather(*(ws.close(code=1001, message=b"Server shutdown")
                           for ws in list(active_connections)), return_exceptions=True)


def make_app() -> web.Application:
    app = web.Application(client_max_size=64 * 1024)
    app.router.add_get("/", handle_index)
    app.router.add_get("/index.html", handle_index)
    app.router.add_get("/ws", handle_websocket)
    app.router.add_get("/health", health)
    app.router.add_get("/local-invite", local_invite)
    app.on_shutdown.append(on_shutdown)
    return app


if __name__ == "__main__":
    port = int(os.getenv("PORT", "3000"))
    print(f"Lanumaren server listening on http://0.0.0.0:{port}", flush=True)
    web.run_app(make_app(), host="0.0.0.0", port=port, access_log=None)
